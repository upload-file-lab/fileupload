import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Copy, Check } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

interface Endpoint {
  method: string;
  path: string;
  description: string;
  code: string;
}

const API_ENDPOINTS: Endpoint[] = [
  {
    method: "POST",
    path: "/api/upload",
    description: "Upload file dan dapatkan URL langsung",
    code: `const form = new FormData();
form.append('file', fileBuffer);

const response = await fetch('/api/upload', {
  method: 'POST',
  body: form
});

const { url, fileId } = await response.json();`
  },
  {
    method: "GET",
    path: "/api/files/:id",
    description: "Dapatkan informasi metadata file",
    code: `const response = await fetch('/api/files/abc123');
const metadata = await response.json();`
  }
];

export default function Docs() {
  const { toast } = useToast();
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const copyToClipboard = async (text: string, index: number) => {
    await navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    toast({
      description: "Berhasil disalin ke clipboard",
      duration: 2000,
    });
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-4xl mx-auto space-y-8"
      >
        <div className="text-center space-y-2">
          <h1 className="text-4xl font-bold">API Documentation</h1>
          <p className="text-muted-foreground">
            Integrasi layanan file hosting dengan aplikasi Anda
          </p>
        </div>

        <div className="grid gap-6">
          {API_ENDPOINTS.map((endpoint, index) => (
            <motion.div
              key={endpoint.path}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-1 text-xs font-medium rounded ${
                        endpoint.method === 'POST' 
                          ? 'bg-green-100 text-green-700' 
                          : 'bg-blue-100 text-blue-700'
                      }`}>
                        {endpoint.method}
                      </span>
                      <code className="relative rounded bg-muted px-[0.5rem] py-[0.2rem] font-mono text-sm">
                        {endpoint.path}
                      </code>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => copyToClipboard(endpoint.path, index)}
                      >
                        {copiedIndex === index ? (
                          <Check className="h-4 w-4" />
                        ) : (
                          <Copy className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {endpoint.description}
                    </p>
                  </div>
                </div>

                <div className="relative">
                  <pre className="rounded-lg bg-muted p-4 overflow-x-auto">
                    <code className="text-sm">{endpoint.code}</code>
                  </pre>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute top-2 right-2"
                    onClick={() => copyToClipboard(endpoint.code, index + API_ENDPOINTS.length)}
                  >
                    {copiedIndex === index + API_ENDPOINTS.length ? (
                      <Check className="h-4 w-4" />
                    ) : (
                      <Copy className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>

        <div className="rounded-lg bg-muted p-6 space-y-4">
          <h2 className="text-xl font-semibold">Contoh Integrasi dengan Bot WhatsApp</h2>
          <div className="relative">
            <pre className="rounded-lg bg-background p-4 overflow-x-auto">
              <code className="text-sm">{`import fetch from "node-fetch";
import { FormData, Blob } from "formdata-node";
import { fileTypeFromBuffer } from "file-type";

const tourl = async (m, { conn }) => {
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || "";
  if (!mime) return m.reply("No media found");

  let media = await q.download();
  let link = await uploadToServer(media);

  let caption = \`📮 *L I N K :*
\${link}
📊 *S I Z E :* \${formatBytes(media.length)}
📛 *E x p i r e d :* Tidak ada batas waktu\`;

  m.reply(caption);
};

async function uploadToServer(content) {
  const { ext, mime } = await fileTypeFromBuffer(content) || {};
  const blob = new Blob([content.toArrayBuffer()], { type: mime });
  const formData = new FormData();
  formData.append("file", blob, \`file.\${ext}\`);

  const response = await fetch("http://your-domain.com/api/upload", {
    method: "POST",
    body: formData,
    headers: {
      "User-Agent": "WhatsApp-Bot/1.0",
    },
  });

  const data = await response.json();
  return data.url;
}`}</code>
            </pre>
            <Button
              variant="ghost"
              size="icon"
              className="absolute top-2 right-2"
              onClick={() => copyToClipboard(
                document.querySelector('pre code')?.textContent || '', 
                API_ENDPOINTS.length * 2
              )}
            >
              {copiedIndex === API_ENDPOINTS.length * 2 ? (
                <Check className="h-4 w-4" />
              ) : (
                <Copy className="h-4 w-4" />
              )}
            </Button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
