import type { Express } from "express";
import express from "express";
import { createServer } from "http";
import multer from 'multer';
import path from 'path';
import { storage } from "./storage";
import { supportedMimeTypes } from "@shared/schema";

const upload = multer({
  dest: 'uploads/',
  limits: {
    fileSize: 100 * 1024 * 1024 // 100MB
  },
  fileFilter: (_req, file, cb) => {
    if (supportedMimeTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Unsupported file type'));
    }
  }
});

export async function registerRoutes(app: Express) {
  // Initialize storage
  await storage.initialize();

  // Serve uploaded files
  app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));

  // File upload endpoint
  app.post('/api/upload', upload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: 'No file uploaded' });
      }

      const metadata = await storage.saveFile(req.file);

      // Generate direct URL
      const host = req.get('host');
      const protocol = req.protocol;
      const url = `${protocol}://${host}/uploads/${metadata.filePath}`;

      res.json({ 
        url,
        fileId: metadata.id
      });
    } catch (err) {
      console.error('Upload error:', err);
      res.status(500).json({ message: 'Upload failed' });
    }
  });

  // Get file metadata
  app.get('/api/files/:id', async (req, res) => {
    const file = await storage.getFile(req.params.id);
    if (!file) {
      return res.status(404).json({ message: 'File not found' });
    }
    res.json(file);
  });

  const httpServer = createServer(app);
  return httpServer;
}