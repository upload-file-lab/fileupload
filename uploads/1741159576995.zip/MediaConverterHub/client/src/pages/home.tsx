import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { UploadZone } from "@/components/upload-zone";
import { motion } from "framer-motion";
import { Book } from "lucide-react";
import { Link } from "wouter";

export default function Home() {
  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-2xl space-y-8"
      >
        <div className="text-center space-y-2">
          <motion.h1 
            className="text-4xl font-bold bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent"
            initial={{ scale: 0.9 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            Simple File Host
          </motion.h1>
          <p className="text-muted-foreground">
            Upload images and media files. Get direct URLs instantly.
          </p>
          <Link href="/docs">
            <Button
              variant="outline"
              className="mt-2"
            >
              <Book className="mr-2 h-4 w-4" />
              API Documentation
            </Button>
          </Link>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="p-6 border-2 hover:border-primary/50 transition-colors">
            <UploadZone />
          </Card>
        </motion.div>

        <div className="text-center text-sm">
          <p className="text-muted-foreground">
            Supported formats: JPG, PNG, MP4, MP3 (Max 100MB)
          </p>
          <p className="text-xs text-muted-foreground/70 mt-1">
            Files are served directly • No registration required
          </p>
        </div>
      </motion.div>
    </div>
  );
}