# Simple File Host

Layanan hosting file sederhana mirip catbox.moe dengan dukungan API untuk bot WhatsApp.

## 📋 Deskripsi

Website ini menyediakan layanan upload file dengan fitur:
- Upload file gambar (JPG, PNG, WEBP), video (MP4, GIF), dan audio (MP3, OPUS)
- Mendapatkan URL langsung setelah upload
- Dukungan API untuk integrasi dengan bot WhatsApp
- Penyimpanan menggunakan database.json
- Ukuran file maksimal 100MB

## 🚀 Cara Menjalankan Website

1. Pastikan Node.js sudah terinstall (versi 18 atau lebih baru)

2. Install dependencies:
```bash
npm install
```

3. Jalankan website:
```bash
npm run dev
```

4. Buka browser dan akses `http://localhost:5000`

## 📁 Struktur Folder

- `/uploads` - Folder penyimpanan file yang diupload
- `/database.json` - Database untuk menyimpan metadata file
- `/server` - Kode backend
- `/client` - Kode frontend

## 🔧 Konfigurasi

Seluruh konfigurasi disimpan dalam file-file berikut:
- `shared/schema.ts` - Pengaturan tipe file yang didukung dan ukuran maksimal
- `server/storage.ts` - Pengaturan lokasi penyimpanan file dan database

## 🤖 Panduan API untuk Bot WhatsApp

### Upload File
```http
POST /api/upload
Content-Type: multipart/form-data

file: <file>
```

Response sukses:
```json
{
  "url": "http://domain.com/uploads/abc123.jpg",
  "fileId": "abc123"
}
```

### Mendapatkan Info File
```http
GET /api/files/:id
```

Response:
```json
{
  "id": "abc123",
  "originalName": "foto.jpg",
  "filePath": "abc123.jpg",
  "mimeType": "image/jpeg",
  "uploadDate": "2024-02-27T12:00:00.000Z",
  "fileSize": 1024
}
```

### Contoh Penggunaan di Bot WhatsApp
```javascript
import fetch from "node-fetch";
import { FormData, Blob } from "formdata-node";
import { fileTypeFromBuffer } from "file-type";

const tourl = async (m, { conn }) => {
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || "";
  if (!mime) return m.reply("No media found");

  let media = await q.download();
  let link = await uploadToServer(media);

  let caption = `📮 *L I N K :*
${link}
📊 *S I Z E :* ${formatBytes(media.length)}
📛 *E x p i r e d :* Tidak ada batas waktu

`;

  m.reply(caption);
};

tourl.command = tourl.help = ['tourl', 'tolink'];
tourl.tags = ['tools', 'internet'];
tourl.limit = true;
export default tourl;

// Helper functions
function formatBytes(bytes) {
  if (bytes === 0) return "0 B";
  const sizes = ["B", "KB", "MB", "GB", "TB"];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / 1024 ** i).toFixed(2)} ${sizes[i]}`;
}

async function uploadToServer(content) {
  const { ext, mime } = await fileTypeFromBuffer(content) || {};
  const blob = new Blob([content.toArrayBuffer()], { type: mime });
  const formData = new FormData();
  formData.append("file", blob, `file.${ext}`);

  const response = await fetch("http://your-domain.com/api/upload", {
    method: "POST",
    body: formData,
    headers: {
      "User-Agent": "WhatsApp-Bot/1.0",
    },
  });

  const data = await response.json();
  return data.url;
}
```

## 📝 Format File yang Didukung

- Gambar: JPG, PNG, WEBP
- Video: MP4, GIF
- Audio: MP3, OPUS, MPA
- Ukuran maksimal: 100MB

## ⚠️ Catatan Penting

- Pastikan folder `/uploads` memiliki permission write
- Backup file `database.json` secara berkala
- Hapus file lama di folder uploads jika sudah tidak digunakan

## 🚀 Deployment ke Produksi

1. Build project:
```bash
npm run build
```

2. Jalankan di mode produksi:
```bash
npm run start
```

## 🤝 Kontribusi

Silakan buat issue atau pull request jika ingin berkontribusi pada project ini.

## 📜 Lisensi

MIT License