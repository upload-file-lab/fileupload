import { uploadSchema, type UploadResponse } from "@shared/schema";

export async function uploadFile(
  file: File, 
  onProgress?: (progress: number) => void
): Promise<UploadResponse> {
  // Validate file
  const result = uploadSchema.safeParse({ file });
  if (!result.success) {
    throw new Error(result.error.errors[0].message);
  }

  const formData = new FormData();
  formData.append('file', file);

  const xhr = new XMLHttpRequest();

  // Setup progress tracking
  if (onProgress) {
    xhr.upload.onprogress = (event) => {
      if (event.lengthComputable) {
        const progress = Math.round((event.loaded / event.total) * 100);
        onProgress(progress);
      }
    };
  }

  // Send request
  return new Promise((resolve, reject) => {
    xhr.open('POST', '/api/upload');

    xhr.onload = () => {
      if (xhr.status === 200) {
        resolve(JSON.parse(xhr.responseText));
      } else {
        reject(new Error(xhr.responseText));
      }
    };

    xhr.onerror = () => {
      reject(new Error('Network error'));
    };

    xhr.send(formData);
  });
}
