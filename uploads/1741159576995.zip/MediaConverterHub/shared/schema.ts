import { z } from "zod";

// File metadata schema
export interface FileMetadata {
  id: string;
  originalName: string;
  filePath: string;
  mimeType: string;
  uploadDate: string;
  fileSize: number;
}

// Database schema
export interface Database {
  files: FileMetadata[];
}

// Upload response
export interface UploadResponse {
  url: string;
  fileId: string;
}

// Validation schemas
export const supportedMimeTypes = [
  'image/jpeg',
  'image/jpg',
  'image/png',
  'image/webp',
  'video/mp4',
  'video/gif',
  'audio/mpeg',
  'audio/opus',
  'audio/mpa'
];

export const uploadSchema = z.object({
  file: z.instanceof(File).refine(
    (file) => supportedMimeTypes.includes(file.type),
    "Format file yang didukung: JPG, PNG, WEBP, MP4, GIF, MP3, OPUS"
  ).refine(
    (file) => file.size <= 100 * 1024 * 1024,
    "Ukuran file maksimal 100MB"
  )
});

export type UploadSchemaType = z.infer<typeof uploadSchema>;