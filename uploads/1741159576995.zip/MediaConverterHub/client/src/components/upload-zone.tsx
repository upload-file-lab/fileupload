import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { Upload, Copy, ExternalLink } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { uploadFile } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import { supportedMimeTypes } from "@shared/schema";

export function UploadZone() {
  const { toast } = useToast();
  const [progress, setProgress] = useState(0);
  const [uploadedUrl, setUploadedUrl] = useState<string>();
  const [isUploading, setIsUploading] = useState(false);

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file) return;

    try {
      setIsUploading(true);
      setProgress(0);
      setUploadedUrl(undefined);

      const { url } = await uploadFile(file, (progress) => {
        setProgress(progress);
      });

      setUploadedUrl(url);
      toast({
        title: "Success!",
        description: "File uploaded successfully",
        duration: 3000,
      });
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Upload failed",
        description: err instanceof Error ? err.message : "Something went wrong",
      });
    } finally {
      setIsUploading(false);
    }
  }, [toast]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    maxFiles: 1,
    accept: supportedMimeTypes.reduce((acc, type) => {
      acc[type] = [];
      return acc;
    }, {} as Record<string, string[]>)
  });

  const copyUrl = useCallback(() => {
    if (uploadedUrl) {
      navigator.clipboard.writeText(uploadedUrl);
      toast({
        description: "URL copied to clipboard",
        duration: 2000,
      });
    }
  }, [uploadedUrl, toast]);

  return (
    <div className="space-y-4">
      <motion.div
        {...getRootProps()}
        className={`
          border-2 border-dashed rounded-lg p-8
          flex flex-col items-center justify-center
          cursor-pointer transition-all duration-200
          ${isDragActive ? "border-primary bg-primary/5" : "border-muted hover:border-primary/50"}
        `}
        whileHover={{ scale: 1.01 }}
        whileTap={{ scale: 0.99 }}
      >
        <input {...getInputProps()} />

        <motion.div 
          initial={{ scale: 0.8 }}
          animate={{ scale: 1 }}
          className="mb-4"
        >
          <Upload className={`h-10 w-10 ${isDragActive ? 'text-primary' : 'text-muted-foreground'}`} />
        </motion.div>

        <div className="text-center space-y-2">
          <p className="text-sm font-medium">
            {isDragActive ? "Drop file here" : "Drag & drop a file here"}
          </p>
          <p className="text-sm text-muted-foreground">
            Or click to select a file
          </p>
        </div>
      </motion.div>

      <AnimatePresence>
        {isUploading && (
          <motion.div 
            className="space-y-2"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
          >
            <Progress value={progress} className="h-1" />
            <p className="text-sm text-center text-muted-foreground">
              Uploading... {progress}%
            </p>
          </motion.div>
        )}

        {uploadedUrl && (
          <motion.div 
            className="space-y-2"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
          >
            <div className="flex items-center gap-2 p-2 bg-muted rounded">
              <input
                type="text"
                value={uploadedUrl}
                readOnly
                className="flex-1 bg-transparent border-none focus:outline-none text-sm px-2"
                onClick={(e) => e.currentTarget.select()}
              />
              <Button
                variant="ghost"
                size="icon"
                onClick={copyUrl}
                title="Copy URL"
                className="hover:text-primary"
              >
                <Copy className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => window.open(uploadedUrl, '_blank')}
                title="Open in new tab"
                className="hover:text-primary"
              >
                <ExternalLink className="h-4 w-4" />
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}