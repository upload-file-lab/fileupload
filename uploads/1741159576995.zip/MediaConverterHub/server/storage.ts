import fs from 'fs/promises';
import path from 'path';
import { nanoid } from 'nanoid';
import type { FileMetadata, Database } from '@shared/schema';

const DB_PATH = path.join(process.cwd(), 'database.json');
const UPLOADS_DIR = path.join(process.cwd(), 'uploads');

export interface IStorage {
  saveFile(file: Express.Multer.File): Promise<FileMetadata>;
  getFile(id: string): Promise<FileMetadata | undefined>;
  initialize(): Promise<void>;
}

export class JsonStorage implements IStorage {
  private db: Database = { files: [] };

  async initialize() {
    try {
      // Ensure uploads directory exists with proper permissions
      await fs.mkdir(UPLOADS_DIR, { recursive: true, mode: 0o755 });

      // Test write permissions
      const testFile = path.join(UPLOADS_DIR, '.test');
      await fs.writeFile(testFile, 'test');
      await fs.unlink(testFile);

      // Load or create database
      try {
        const data = await fs.readFile(DB_PATH, 'utf-8');
        this.db = JSON.parse(data);
      } catch (err) {
        if ((err as NodeJS.ErrnoException).code === 'ENOENT') {
          // Create new DB if doesn't exist
          await this.saveDb();
        } else {
          throw new Error('Failed to read database: ' + err);
        }
      }
    } catch (err) {
      console.error('Failed to initialize storage:', err);
      throw new Error('Storage initialization failed. Please check folder permissions and database access.');
    }
  }

  private async saveDb() {
    try {
      await fs.writeFile(DB_PATH, JSON.stringify(this.db, null, 2));
    } catch (err) {
      console.error('Failed to save database:', err);
      throw new Error('Could not save to database. Please check file permissions.');
    }
  }

  async saveFile(file: Express.Multer.File): Promise<FileMetadata> {
    try {
      const id = nanoid(10);
      const ext = path.extname(file.originalname);
      const filePath = `${id}${ext}`;
      const fullPath = path.join(UPLOADS_DIR, filePath);

      // Move uploaded file to permanent location
      await fs.rename(file.path, fullPath);

      // Verify file was moved successfully
      await fs.access(fullPath);

      const metadata: FileMetadata = {
        id,
        originalName: file.originalname,
        filePath,
        mimeType: file.mimetype,
        uploadDate: new Date().toISOString(),
        fileSize: file.size
      };

      this.db.files.push(metadata);
      await this.saveDb();

      return metadata;
    } catch (err) {
      console.error('Failed to save file:', err);
      throw new Error('File upload failed. Please try again.');
    }
  }

  async getFile(id: string): Promise<FileMetadata | undefined> {
    try {
      const file = this.db.files.find(f => f.id === id);
      if (file) {
        // Verify file still exists
        await fs.access(path.join(UPLOADS_DIR, file.filePath));
      }
      return file;
    } catch (err) {
      console.error('Failed to get file:', err);
      return undefined;
    }
  }
}

export const storage = new JsonStorage();